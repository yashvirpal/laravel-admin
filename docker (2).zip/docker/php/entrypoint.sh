#!/bin/sh

echo "Fixing permissions..."
mkdir -p storage/framework/{cache,sessions,views}
mkdir -p storage/logs
mkdir -p bootstrap/cache

chmod -R 777 storage
chmod -R 777 bootstrap/cache

# Install dependencies
if [ ! -d vendor ]; then
    echo "Installing composer packages..."
    composer install --no-interaction --prefer-dist --optimize-autoloader
fi

echo "Waiting for database to be ready..."
until nc -z "$DB_HOST" "$DB_PORT"; do
  echo "Database not ready... retrying"
  sleep 2
done
echo "Database is ready!"

echo "Generating migration tables..."
# These MUST run BEFORE migrate
# php artisan cache:table
# php artisan session:table
# php artisan queue:table

echo "Running migrations..."
php artisan migrate --force
#php artisan db:seed --force || true


php artisan optimize:clear
php artisan optimize

#echo "Starting PHP-FPM..."
#exec "$@"
#exec php-fpm
echo "Starting container process..."
exec "$@"

